import "./App.css";
import ManagementPage from "./layout/ManagementPage";

function App() {
  return (
    <div className="App">
      <ManagementPage />
    </div>
  );
}

export default App;
