Library: React js;

Api: mock api data;

features: Add, edit, delete, toast;

responsive: Fully responsive;

styles library: Tailwind css;


****  deployed project is accessible on:   https://hamraheaval.iran.liara.run/   ***